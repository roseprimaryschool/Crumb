
import React, { useState } from 'react';
import { Product } from '../types';

const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'The Signature Orange Zest',
    description: 'Our flagship cookie. Bright citrus notes meet a chewy, protein-packed core.',
    price: 4.50,
    image: 'https://picsum.photos/seed/orange-cookie/500/500',
    protein: '15g',
    calories: '210'
  },
  {
    id: '2',
    name: 'Choco-Almond Power',
    description: 'Dark chocolate chunks with roasted almonds and a hint of orange blossom.',
    price: 4.75,
    image: 'https://picsum.photos/seed/choco-cookie/500/500',
    protein: '16g',
    calories: '230'
  },
  {
    id: '3',
    name: 'Double Zest Protein Pack (6)',
    description: 'A half-dozen of our finest. Perfect for meal prep or sharing with friends.',
    price: 24.00,
    image: 'https://picsum.photos/seed/cookie-pack/500/500',
    protein: '90g Total',
    calories: '1260 Total'
  },
  {
    id: '4',
    name: 'Golden Honey & Oat',
    description: 'The ultimate breakfast cookie. Soft, filling, and naturally sweetened.',
    price: 4.25,
    image: 'https://picsum.photos/seed/honey-cookie/500/500',
    protein: '14g',
    calories: '190'
  }
];

export const Shop: React.FC = () => {
  const [cartCount, setCartCount] = useState(0);
  const [lastAdded, setLastAdded] = useState<string | null>(null);

  const handleAddToCart = (name: string) => {
    setCartCount(prev => prev + 1);
    setLastAdded(name);
    setTimeout(() => setLastAdded(null), 3000);
  };

  return (
    <div className="bg-[#FFFBEB] min-h-screen py-16">
      <div className="max-w-6xl mx-auto px-4">
        <header className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div className="text-left">
            <h1 className="text-5xl font-bold text-[#78350F] mb-4">Our Bakery Shop</h1>
            <p className="text-[#9A3412] text-xl">Baked fresh today, shipped to you tomorrow.</p>
          </div>
          <div className="bg-white px-6 py-3 rounded-full border-2 border-[#EA580C] flex items-center gap-3 shadow-sm">
            <span className="text-[#78350F] font-bold">🛒 Cart</span>
            <span className="bg-[#EA580C] text-white w-8 h-8 rounded-full flex items-center justify-center font-bold">{cartCount}</span>
          </div>
        </header>

        {lastAdded && (
          <div className="fixed top-24 right-4 z-50 bg-[#F97316] text-white px-6 py-3 rounded-lg shadow-xl animate-bounce">
            Added "{lastAdded}" to your basket! 🍪
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PRODUCTS.map((product) => (
            <div key={product.id} className="bg-white rounded-3xl overflow-hidden shadow-sm border border-[#FED7AA] flex flex-col group transition-all hover:shadow-xl">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-[#78350F] text-xs font-bold border border-[#FED7AA]">
                  {product.protein} Protein
                </div>
              </div>
              
              <div className="p-6 flex flex-col flex-grow">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-bold text-[#78350F] leading-tight">{product.name}</h3>
                  <span className="text-[#EA580C] font-bold text-lg">${product.price.toFixed(2)}</span>
                </div>
                <p className="text-[#9A3412] text-sm mb-6 flex-grow">{product.description}</p>
                <div className="flex items-center justify-between text-xs text-[#9A3412] mb-6 opacity-60 font-medium">
                  <span>{product.calories} calories</span>
                  <span>Handcrafted</span>
                </div>
                <button 
                  onClick={() => handleAddToCart(product.name)}
                  className="w-full py-3 bg-[#FFF7ED] text-[#EA580C] border-2 border-[#EA580C] rounded-xl font-bold hover:bg-[#EA580C] hover:text-white transition-colors duration-300"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 bg-[#FFEDD5] rounded-3xl p-12 text-center border-2 border-dashed border-[#EA580C]">
          <h2 className="text-3xl font-bold text-[#78350F] mb-4">Hungry for something specific?</h2>
          <p className="text-[#9A3412] mb-8 max-w-xl mx-auto">We do custom batches for events, gyms, and offices. Drop us a message and let's bake something special!</p>
          <button className="px-8 py-3 bg-[#78350F] text-white rounded-full font-bold hover:bg-[#451A03] transition">
            Contact Custom Bakery
          </button>
        </div>
      </div>
    </div>
  );
};
