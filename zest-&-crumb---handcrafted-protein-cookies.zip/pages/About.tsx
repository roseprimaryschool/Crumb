
import React from 'react';

export const About: React.FC = () => {
  return (
    <div className="bg-[#FFFBEB] min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4">
        <header className="text-center mb-16">
          <h1 className="text-5xl font-bold text-[#78350F] mb-6">Our Small Batch Story</h1>
          <p className="text-xl text-[#9A3412] italic">From a tiny home kitchen to your front door.</p>
        </header>

        <div className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-[#FED7AA] space-y-8">
          <div className="flex flex-col md:flex-row gap-10 items-center">
            <img 
              src="https://picsum.photos/seed/baker/400/400" 
              alt="Our founder baking" 
              className="w-full md:w-1/2 rounded-2xl shadow-lg border-4 border-[#FFFBEB]"
            />
            <div className="space-y-4">
              <h2 className="text-3xl font-bold text-[#78350F]">It Started with a Cravings</h2>
              <p className="text-[#9A3412] leading-relaxed">
                Zest & Crumb was born from a simple problem: finding a protein snack that didn't taste like cardboard. Our founder, an avid hiker and home baker, spent months in a small kitchen experimenting with orange peels, organic honey, and premium protein powders.
              </p>
              <p className="text-[#9A3412] leading-relaxed">
                After 142 failed batches, we finally found the magic ratio—a cookie that felt like a decadent treat but provided the clean energy needed for a busy life.
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-[#FED7AA]">
            <h2 className="text-3xl font-bold text-[#78350F] text-center mb-6">Our Mission</h2>
            <div className="bg-[#FFEDD5] p-10 rounded-2xl text-center">
              <p className="text-2xl font-serif text-[#78350F] italic leading-relaxed">
                "Healthy shouldn’t mean flavorless — every snack deserves to taste incredible."
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8">
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-[#78350F]">Why Orange?</h3>
              <p className="text-[#9A3412]">
                Orange isn't just a color—it's a feeling. The zest provides a bright, natural sweetness that balances the rich protein base. It's sunshine in cookie form.
              </p>
            </div>
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-[#78350F]">Our Community</h3>
              <p className="text-[#9A3412]">
                We aren't a massive factory. We're a small team that hand-packs every order. When you buy from us, you're supporting a dream of making the world a little sweeter, one healthy bite at a time.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
