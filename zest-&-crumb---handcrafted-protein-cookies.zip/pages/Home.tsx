
import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from '../components/Logo';

export const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-[#FFFBEB] py-20 lg:py-32">
        <div className="max-w-6xl mx-auto px-4 flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 text-center lg:text-left space-y-6">
            <div className="inline-block p-2 bg-[#FFEDD5] rounded-full mb-2">
              <Logo className="w-16 h-16 lg:w-20 lg:h-20" />
            </div>
            <h1 className="text-5xl lg:text-7xl font-bold text-[#78350F] leading-tight">
              Bites of Sunshine, <br />
              <span className="text-[#EA580C]">Packed with Protein</span>
            </h1>
            <p className="text-xl text-[#9A3412] max-w-lg mx-auto lg:mx-0">
              The only protein cookie that actually tastes like it came from Grandma's oven. Handcrafted with love and orange zest.
            </p>
            <div className="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
              <Link to="/shop" className="px-8 py-4 bg-[#EA580C] text-white rounded-full font-bold shadow-lg hover:bg-[#C2410C] transition transform hover:-translate-y-1">
                Shop Fresh Cookies
              </Link>
              <Link to="/about" className="px-8 py-4 bg-white text-[#EA580C] border-2 border-[#EA580C] rounded-full font-bold hover:bg-[#FFF7ED] transition transform hover:-translate-y-1">
                Our Story
              </Link>
            </div>
          </div>
          <div className="flex-1 relative">
            <div className="absolute inset-0 bg-[#FED7AA] rounded-full blur-3xl opacity-30 scale-125"></div>
            <img 
              src="https://picsum.photos/seed/cookies/600/600" 
              alt="Delicious orange cookies" 
              className="relative z-10 rounded-3xl shadow-2xl border-8 border-white transform rotate-3"
            />
          </div>
        </div>
      </section>

      {/* Featured Features */}
      <section className="bg-white py-20 border-y border-[#FED7AA]">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#78350F] mb-4">Why Zest & Crumb?</h2>
            <div className="w-24 h-1 bg-[#EA580C] mx-auto rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { 
                title: "15g High Protein", 
                desc: "Powered by premium whey and pea proteins to keep you full and fueled.",
                icon: "💪"
              },
              { 
                title: "Small Batch", 
                desc: "Hand-mixed and slowly baked to ensure every cookie is perfect.",
                icon: "👨‍🍳"
              },
              { 
                title: "Natural Ingredients", 
                desc: "No artificial flavors. Just real orange zest, honey, and oats.",
                icon: "🍊"
              }
            ].map((f, i) => (
              <div key={i} className="bg-[#FFFBEB] p-8 rounded-2xl border border-[#FED7AA] text-center hover:shadow-md transition">
                <div className="text-5xl mb-6">{f.icon}</div>
                <h3 className="text-2xl font-bold text-[#78350F] mb-4">{f.title}</h3>
                <p className="text-[#9A3412] leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-24 bg-[#FFF7ED]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <span className="text-6xl text-[#EA580C] opacity-30 font-serif">"</span>
          <p className="text-3xl lg:text-4xl font-serif italic text-[#78350F] leading-snug">
            Healthy shouldn’t mean flavorless — every snack deserves to taste incredible.
          </p>
          <div className="mt-8 text-lg font-bold text-[#9A3412]">— Our Kitchen Philosophy</div>
        </div>
      </section>
    </div>
  );
};
