
import React from 'react';

const INGREDIENTS = [
  {
    name: "Premium Whey & Pea Protein",
    benefit: "A complete amino acid profile to support muscle recovery and keep you full longer.",
    icon: "🧬"
  },
  {
    name: "Organic Valencia Oranges",
    benefit: "Zested fresh for every batch to provide vitamin C and bright, natural citrus flavor.",
    icon: "🍊"
  },
  {
    name: "Steel Cut Oats",
    benefit: "High-fiber carbohydrates for sustained energy release throughout your day.",
    icon: "🌾"
  },
  {
    name: "Wildflower Honey",
    benefit: "A natural, low-glycemic sweetener packed with antioxidants and minerals.",
    icon: "🍯"
  },
  {
    name: "Cold-Pressed Coconut Oil",
    benefit: "Healthy fats that provide a rich, soft texture without the need for butter.",
    icon: "🥥"
  },
  {
    name: "Ceylon Cinnamon",
    benefit: "Known for metabolism support and adding a warm, cozy depth of flavor.",
    icon: "🍂"
  }
];

export const Ingredients: React.FC = () => {
  return (
    <div className="bg-[#FFFBEB] min-h-screen py-16">
      <div className="max-w-5xl mx-auto px-4">
        <header className="text-center mb-16">
          <h1 className="text-5xl font-bold text-[#78350F] mb-6">What's Inside?</h1>
          <p className="text-xl text-[#9A3412] max-w-2xl mx-auto">
            We believe in transparency. No mystery fillers, no chemical preservatives—just high-quality, whole-food ingredients you'd find in a kitchen.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {INGREDIENTS.map((ing, idx) => (
            <div key={idx} className="bg-white p-8 rounded-2xl border border-[#FED7AA] flex gap-6 items-start shadow-sm hover:shadow-md transition">
              <div className="text-4xl p-4 bg-[#FFF7ED] rounded-xl border border-[#FED7AA]">
                {ing.icon}
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#78350F] mb-2">{ing.name}</h3>
                <p className="text-[#9A3412] text-sm leading-relaxed">{ing.benefit}</p>
              </div>
            </div>
          ))}
        </div>

        <section className="bg-white rounded-3xl p-10 md:p-16 border border-[#FED7AA] shadow-sm overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#FED7AA] opacity-20 rounded-full -translate-y-1/2 translate-x-1/2"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row gap-12 items-center">
            <div className="flex-1 space-y-6">
              <h2 className="text-4xl font-bold text-[#78350F]">Nutritional Balance</h2>
              <p className="text-[#9A3412] leading-relaxed">
                Every Zest & Crumb cookie is designed to be more than just a snack—it's functional fuel. We balance the macros to ensure you're getting enough protein and fiber without the sugar crash associated with traditional treats.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-1 bg-[#EA580C] rounded-full"></div>
                  <span className="font-bold text-[#78350F]">No Artificial Colors</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-1 bg-[#EA580C] rounded-full"></div>
                  <span className="font-bold text-[#78350F]">Soy-Free & Non-GMO</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-1 bg-[#EA580C] rounded-full"></div>
                  <span className="font-bold text-[#78350F]">Zero Trans Fats</span>
                </div>
              </div>
            </div>
            
            <div className="flex-1 bg-[#FFFBEB] p-8 rounded-2xl border-2 border-[#FED7AA] shadow-inner">
              <h4 className="text-center font-bold text-[#78350F] uppercase tracking-widest text-sm mb-6">Typical Batch Macros</h4>
              <div className="space-y-6">
                {[
                  { label: "Protein", val: "15g", width: "90%" },
                  { label: "Net Carbs", val: "12g", width: "60%" },
                  { label: "Healthy Fats", val: "8g", width: "45%" },
                  { label: "Fiber", val: "6g", width: "40%" }
                ].map((stat, i) => (
                  <div key={i}>
                    <div className="flex justify-between mb-1">
                      <span className="text-[#78350F] font-bold text-sm">{stat.label}</span>
                      <span className="text-[#EA580C] font-bold text-sm">{stat.val}</span>
                    </div>
                    <div className="w-full bg-[#E7E5E4] h-2 rounded-full overflow-hidden">
                      <div className="bg-[#EA580C] h-full" style={{ width: stat.width }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
