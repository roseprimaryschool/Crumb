
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  protein: string;
  calories: string;
}

export interface Ingredient {
  name: string;
  benefit: string;
  icon: string;
}
