
import React from 'react';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#FEF3C7] py-12 border-t border-[#FED7AA]">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
        <div className="flex flex-col items-center md:items-start">
          <div className="flex items-center space-x-2 mb-4">
            <Logo className="w-8 h-8" />
            <span className="text-xl font-bold font-serif text-[#78350F]">Zest & Crumb</span>
          </div>
          <p className="text-[#9A3412] text-sm">
            Baking health into every bite. Small batch, high protein, maximum flavor.
          </p>
        </div>
        
        <div>
          <h4 className="text-[#78350F] font-bold mb-4 uppercase tracking-wider text-sm">Quick Links</h4>
          <ul className="space-y-2 text-[#9A3412]">
            <li><a href="#/" className="hover:underline">Home</a></li>
            <li><a href="#/about" className="hover:underline">Our Story</a></li>
            <li><a href="#/shop" className="hover:underline">Shop Cookies</a></li>
            <li><a href="#/ingredients" className="hover:underline">The Good Stuff</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[#78350F] font-bold mb-4 uppercase tracking-wider text-sm">Contact</h4>
          <p className="text-[#9A3412] text-sm mb-2">123 Cookie Lane, Bakerstown</p>
          <p className="text-[#9A3412] text-sm">hello@zestandcrumb.com</p>
          <div className="mt-4 flex justify-center md:justify-start space-x-4">
            <span className="w-8 h-8 rounded-full bg-[#FB923C] flex items-center justify-center text-white text-xs cursor-pointer">IG</span>
            <span className="w-8 h-8 rounded-full bg-[#FB923C] flex items-center justify-center text-white text-xs cursor-pointer">FB</span>
          </div>
        </div>
      </div>
      <div className="mt-8 text-center text-[#9A3412] text-xs opacity-60">
        &copy; {new Date().getFullYear()} Zest & Crumb Cookies. All rights reserved.
      </div>
    </footer>
  );
};
