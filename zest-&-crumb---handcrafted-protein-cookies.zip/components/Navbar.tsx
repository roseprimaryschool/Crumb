
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Logo } from './Logo';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-[#FFFBEB] border-b border-[#FED7AA] sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Logo className="w-10 h-10" />
              <span className="text-2xl font-bold font-serif text-[#78350F]">Zest & Crumb</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-[#9A3412] hover:text-[#F97316] font-medium transition">Home</Link>
            <Link to="/about" className="text-[#9A3412] hover:text-[#F97316] font-medium transition">About Us</Link>
            <Link to="/shop" className="text-[#9A3412] hover:text-[#F97316] font-medium transition">Shop</Link>
            <Link to="/ingredients" className="text-[#9A3412] hover:text-[#F97316] font-medium transition">Ingredients</Link>
          </div>

          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-[#78350F] focus:outline-none"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-[#FFFBEB] pb-4 px-4 space-y-2 border-t border-[#FED7AA]">
          <Link to="/" onClick={() => setIsOpen(false)} className="block py-2 text-[#9A3412] font-medium">Home</Link>
          <Link to="/about" onClick={() => setIsOpen(false)} className="block py-2 text-[#9A3412] font-medium">About Us</Link>
          <Link to="/shop" onClick={() => setIsOpen(false)} className="block py-2 text-[#9A3412] font-medium">Shop</Link>
          <Link to="/ingredients" onClick={() => setIsOpen(false)} className="block py-2 text-[#9A3412] font-medium">Ingredients</Link>
        </div>
      )}
    </nav>
  );
};
