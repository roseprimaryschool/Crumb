
import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => (
  <svg 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={className}
  >
    <circle cx="50" cy="50" r="45" fill="#FB923C" fillOpacity="0.2" />
    <path 
      d="M30 50C30 38.9543 38.9543 30 50 30C61.0457 30 70 38.9543 70 50C70 61.0457 61.0457 70 50 70C38.9543 70 30 61.0457 30 50Z" 
      stroke="#78350F" 
      strokeWidth="4" 
      strokeLinecap="round" 
    />
    <path 
      d="M45 40L55 60M55 40L45 60" 
      stroke="#78350F" 
      strokeWidth="4" 
      strokeLinecap="round" 
    />
    <circle cx="75" cy="25" r="8" fill="#F97316" />
    <path 
      d="M50 20C55 20 60 25 60 30" 
      stroke="#78350F" 
      strokeWidth="2" 
      strokeLinecap="round" 
    />
  </svg>
);
